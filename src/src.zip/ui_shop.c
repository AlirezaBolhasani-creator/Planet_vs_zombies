//
// Created by asus on 1/21/2026.
//
#include "ui_shop.h"
#include "plant.h"

#define y_start 200
#define x_start 150
#define SLOT_W 100
#define GAP 150

void draw_shop_bar(Texture2D shop, Texture2D shop_rect)
{
    Rectangle src_bar = {0, 0, (float)shop.width, (float)shop.height};
    Rectangle dst_bar = {0, 0, 1200, 250};
    DrawTexturePro(shop, src_bar, dst_bar, (Vector2){0,0}, 0, WHITE);
    for(int i = 0; i < number_of_plants; i++)
    {
        Rectangle src_rect = {0, 0, shop_rect.width, shop_rect.height};
        Rectangle dst_rect = {x_start * i + x_start, y_start , 100, 100};
        Vector2 origin_rect = {dst_rect.width/2, dst_rect.height/2};
        DrawTexturePro(shop_rect, src_rect, dst_rect, origin_rect,0, WHITE);
    }
}
void set_plants_shop(Plant plants[number_of_plants], plant_type type, int i)
{
    plants[i].type = type;
}
void draw_plant_shop(Texture2D plants_tex[number_of_plants], Plant plants[number_of_plants])
{
    for(int i = 0; i < number_of_plants; i++)
    {
        Rectangle src_rect = {0, 0, plants_tex[i].width, plants_tex[i].height};
        Rectangle dst_rect = {x_start * i + x_start - 55 , y_start - 50, 100, 100};
        Vector2 origin_rect = {0,0};
        DrawTexturePro(plants_tex[i], src_rect, dst_rect, origin_rect,0, WHITE);
    }
}
int is_on_shop_plant(int x, int y)
{
    int top = y_start - 50;
    int bottom = y_start + SLOT_W - 50;

    if (y < top || y > bottom) return 0;

    for (int i = 0; i < number_of_plants; i++)
    {
        int centerX = x_start + i * GAP;
        int left = centerX - SLOT_W/2;
        int right = centerX + SLOT_W/2;

        if (x >= left && x <= right) return i;
    }
    return 0;
}
void mouse_on_shop(int x, int y)
{
    int top = y_start - 50;
    int bottom = y_start + SLOT_W - 50;

    if (y < top || y > bottom) return ;

    for (int i = 0; i < number_of_plants; i++)
    {
        int centerX = x_start + i * GAP;
        int left = centerX - SLOT_W/2;
        int right = centerX + SLOT_W/2;

        if (x >= left && x <= right)
        {
            Rectangle lines = {left, top, SLOT_W, SLOT_W};
            DrawRectangleLinesEx(lines, 5, YELLOW);
        }
    }
    return;
}
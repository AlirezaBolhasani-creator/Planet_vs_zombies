#include "raylib.h"
#include "game.h"
#include "ui_menu.h"
#include "levels.h"
#include "grid.h"
#include "plant.h"
#include "ui_shop.h"
#include <stdio.h>
#include <stdlib.h>
#include "shop.h"
#include "time.h"
#include "sun.h"
#include <math.h>
#include "bullet.h"
#include "zombie.h"
#include "mower.h"

static Texture2D background;
static Texture2D level_back;
static Texture2D grass;
static Texture2D soil;
static Texture2D asphalt;
static Texture2D sunflower;
static Texture2D walnut;
static Texture2D pea;
static Texture2D chomper_tex;

static Texture2D shop_bar;
static Texture2D shop_rect;
static Texture2D shop_back;
static Texture2D forbidden;
static Texture2D sun;
static Grid map;
static Texture2D plants_use_shop[number_of_plants];
static Plant plants_shop[number_of_plants];
static bool level_map_ready = false;
static Plant plants[GRID_ROWS][GRID_COLS];
static int hover_col = -1 , hover_row = -1;
static plant_type selected_plant = PLANT_NONE;
static Texture2D all_plants[all_plants_num];//now 3 later 6
static bool is_bought[all_plants_num];
static plant_shop plantShop[all_plants_num];
static int sun_points = 50;   // امتیاز اولیه‌ی خورشید

static float cd_pea = 0.0f;
static float cd_sunflower = 0.0f;
static float cd_walnut = 0.0f;

static Sun  suns[MAX_SUNS];
static float sun_spawn_timer = 0.0f;

static Bullet bullets[MAX_BULLETS];
static PlantEvent plant_events[MAX_PLANT_EVENTS];

static Zombie zombies[MAX_ZOMBIES];
static Texture2D zombie_tex;
static float zombie_spawn_timer = 0.0f;
static bool game_over;


//Wave system...
static int   wave = 1;
static float wave_timer = 0.0f;
static float spawn_interval = 3.0f;

//mower
static Mower mowers[GRID_ROWS];
static Texture2D mower_tex;

void game_init()
{
    sun_points = 50;
    background = LoadTexture(ASSET("last_menu.png"));
    level_back  = LoadTexture(ASSET("level_final_back.png"));
    grass = LoadTexture(ASSET("light_grass.png"));
    soil = LoadTexture(ASSET("light_grass.png"));
    asphalt = LoadTexture(ASSET("light_grass.png"));
    pea = LoadTexture(ASSET("PEA.png"));
    sunflower = LoadTexture(ASSET("SUNFLOWER.png"));
    walnut = LoadTexture(ASSET("WALNUT.png"));
    shop_bar = LoadTexture(ASSET("shop_bar.png"));
    shop_rect = LoadTexture(ASSET("shop_rect.png"));
    shop_back = LoadTexture(ASSET("shop_back.jpg"));
    forbidden = LoadTexture(ASSET("forbidden.png"));
    sun = LoadTexture(ASSET("SUN.png"));
    mower_tex = LoadTexture(ASSET("mower.png"));
    zombie_tex = LoadTexture(ASSET("zombie.png"));//change it later
    chomper_tex = LoadTexture(ASSET("chomper.png"));

    zombies_init(zombies,MAX_ZOMBIES);

    sun_spawn_timer = 0.0f;
    for (int i = 0; i < MAX_SUNS; ++i)
    {
        suns[i].active   = false;
        suns[i].lifeTime = 0.0f;
        suns[i].row      = 0;
        suns[i].col      = 0;
    }    //
    all_plants[0] = pea; all_plants[1] = sunflower; all_plants[2] = walnut;all_plants[3] = chomper_tex;
    is_bought[0] = true; is_bought[1] = true; is_bought[2] = false; is_bought[3] = true;
    plantShop[0].is_bought = true;plantShop[1].is_bought = true; plantShop[2].is_bought = false;
    //
    PlantTextures tex = {pea, sunflower, walnut, chomper_tex};
    plant_set_textures(tex);

    //use for and take value by shop
    plant_type types[number_of_plants];
    read_in_file(types);
    for(int i = 0; i < number_of_plants; i++)
    {
        if(types[i] == PLANT_SUNFLOWER)
            plants_use_shop[i] = sunflower;
        else if(types[i] == PLANT_WALLNUT)
            plants_use_shop[i] = walnut;
        else if(types[i] == PLANT_PEA)
            plants_use_shop[i] = pea;
        else if(types[i] == PLANT_CHOMPER)
            plants_use_shop[i] = chomper_tex;
        //add more later...
        set_plants_shop(plants_shop,types[i], i);
    }
    bullet_init(bullets);
    mowers_init(mowers);
    srand(time(NULL));
    game_over = false;

}
void game_unload()
{
    UnloadTexture(background);
    UnloadTexture(level_back);
    UnloadTexture(grass);
    UnloadTexture(soil);
    UnloadTexture(asphalt);
    UnloadTexture(pea);
    UnloadTexture(sunflower);
    UnloadTexture(walnut);
    UnloadTexture(shop_bar);
    UnloadTexture(shop_rect);
    UnloadTexture(shop_back);
    UnloadTexture(sun);
    UnloadTexture(forbidden);
    UnloadTexture(zombie_tex);
    UnloadTexture(mower_tex);
    UnloadTexture(chomper_tex);
}
void game_reset_level1()
{
    level_map_ready = false;
    sun_points = 50;
    cd_walnut = cd_pea = cd_sunflower = 0;
    plant_grid_clear(plants);
    bullet_init(bullets);
    zombies_init(zombies, MAX_ZOMBIES);
    sun_spawn_timer = 0.0f;
    zombie_spawn_timer = 0.0f;
    for(int i = 0; i < MAX_SUNS; i++)
    {
        suns[i].active = false;
        suns[i].row = 0;
        suns[i].col = 0;
        suns[i].lifeTime = 0;
    }
    selected_plant = PLANT_NONE;
    hover_col = hover_row = -1;
    wave = 1;
    spawn_interval = 3.0f;
    wave_timer = 0.0f;
    game_over = false;
    mowers_init(mowers);
}
void game_update(enum game_state *game, float dt)
{
    switch (*game)
    {
        case STATE_MENU :
        {
            menu_res res = menu_update();
            if (res == menu_play) *game = STATE_LEVEL_SELECT;
            if (res == menu_shop) *game = STATE_SHOP;
            if (res == menu_exit) *game = STATE_EXIT;
        }break;
        case STATE_LEVEL_SELECT:
        {
            level_res levelRes = update_level();
            if(levelRes == level_one)
            {
                *game = STATE_LEVEL1;
                level_map_ready = false;
            }
            else if(levelRes == level_two)
            {
                *game = STATE_LEVEL2;
                level_map_ready = false;
            }
            else if(levelRes == level_three)
            {
                *game = STATE_LEVEL3;
                level_map_ready = false;
            }
            else if(levelRes == level_four)
            {
                *game = STATE_LEVEL4;
                level_map_ready = false;
            }
        }break;
        case STATE_LEVEL1:
        {
            //Wave-Update...
            wave_timer += dt;
            if(wave_timer >= 20.0f)
            {
                wave++;
                wave_timer = 0.0f;
                spawn_interval = fmaxf(0.8f, spawn_interval - 0.3f);
            }
            update_suns(dt, &sun_spawn_timer, suns);
            zombie_spawn_timer += dt;
            if(zombie_spawn_timer >= spawn_interval)
            {
                zombie_spawn_random_row(zombies, MAX_ZOMBIES);
                zombie_spawn_timer= 0.0f;
            }
            //end_of_wave...
            float rowMul[GRID_ROWS];
            for(int r=0;r<GRID_ROWS;r++) rowMul[r]=1.0f;

            for(int r = 0; r < GRID_ROWS; r++)
            {
                for(int c = 0; c < GRID_COLS; c++)
                {
                    if(plants[r][c].type == PLANT_CHOMPER && plants[r][c].alive)
                    {
                        rowMul[r] = 1.0f/3.0f;
                        break;
                    }
                }
            }

            zombies_update(zombies, MAX_ZOMBIES, dt, plants, &game_over, rowMul);
            mowers_update(mowers,zombies, MAX_ZOMBIES, dt);
            cd_pea = fmaxf(0.0f, cd_pea - dt);
            cd_sunflower = fmaxf(0.0f, cd_sunflower - dt);
            cd_walnut = fmaxf(0.0f, cd_walnut - dt);
            int evCount = plant_collect_events(plants, dt, plant_events, MAX_PLANT_EVENTS);
            for(int i = 0; i < evCount; i++)
            {
                PlantEvent ev = plant_events[i];
                if(ev.type == EVENT_SPAWN_BULLET)
                {
                    spawn_bullet(ev.row, ev.col, bullets);
                }
                else if(ev.type == EVENT_SPAWN_SUN)
                {
                    spawn_sun_at(suns, ev.row, ev.col);
                }
            }
            if (IsKeyPressed(KEY_ONE))selected_plant = PLANT_PEA;
            if (IsKeyPressed(KEY_TWO))selected_plant = PLANT_SUNFLOWER;
            if(IsKeyPressed(KEY_THREE))selected_plant = PLANT_WALLNUT;
            if(IsKeyPressed(KEY_FOUR))selected_plant = PLANT_CHOMPER;
            if(IsKeyPressed(KEY_C))selected_plant = PLANT_NONE;
            if (IsKeyPressed(KEY_F))
            {
                sun_points += 25;
            }
            if(IsKeyPressed(KEY_B)) spawn_bullet(2,2,bullets);
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
            {
                int mc = -1, mr = -1;
                int x_loc = GetMouseX(), y_loc = GetMouseY();
                if(handle_sun_click((Vector2){(float )x_loc,(float )y_loc}, suns, &sun_points))
                {
                    break;
                }
                else if (grid_world_to_cell(x_loc, y_loc, &mc, &mr) && selected_plant != PLANT_NONE)
                {
                    if (grid_can_place_plant(&map, mc, mr))
                    {
                        int cost = PLANT_COST[selected_plant];

                        if (sun_points >= cost)
                        {
                            if (plant_place(plants, selected_plant, mc, mr))
                            {
                                sun_points -= cost;
                                if(selected_plant == PLANT_PEA) cd_pea = 5.0f;
                                else if(selected_plant == PLANT_SUNFLOWER) cd_sunflower = 5.0f;
                                else if(selected_plant == PLANT_WALLNUT) cd_walnut = 5.0f;
                                selected_plant = PLANT_NONE;
                            }
                        }
                        else
                        {
                            // این بخش فقط برای دیباگ و تست:
                            printf("Not enough sun for this plant!\n");
                            // اگر خواستی، می‌تونی بعداً کنار موس متن قرمز هم نشون بدی.
                        }
                    }
                }
                else if(is_on_shop_plant(x_loc, y_loc) > -1)
                {
                    int i = is_on_shop_plant(x_loc,y_loc);
                    if(i == PLANT_PEA && cd_pea > 0.0f) break;
                    if(i  == PLANT_SUNFLOWER && cd_sunflower > 0.0f)break;
                    if(i == PLANT_WALLNUT && cd_walnut > 0.0f)break;
                    selected_plant = plants_shop[i].type;
                }
            }

            if(IsMouseButtonPressed(MOUSE_BUTTON_RIGHT))
            {
                int mc = -1, mr = -1;
                if(grid_world_to_cell(GetMouseX(), GetMouseY(), &mc, &mr))
                {
                    plant_remove(plants,mc, mr);
                }
            }
            hover_col = -1;
            hover_row = -1;
            int mc = -1, mr = -1;
            if(grid_world_to_cell(GetMouseX(), GetMouseY(),&mc, &mr))
            {
                hover_col = mc;
                hover_row = mr;
            }
            bullet_update(bullets,dt);
           
            for(int i = 0;i < MAX_BULLETS; i++)
            {
                if(!bullets[i].active) continue;
                for(int b = 0; b < MAX_ZOMBIES; b++)
                {
                    if(!zombies[b].active)continue;
                    if(bullets[i].row == zombies[b].row && fabsf(bullets[i].x - zombies[b].x) < (TILE_SIZE * 0.05f))
                    {
                        zombies[b].health -= bullets[i].damage;
                        bullets[i].active = false;
                        break;
                    }
                }
            }
            if(game_over == true)
            {
                *game = STATE_GAME_OVER;
            }
        }break;

        case STATE_LEVEL2:
        {
            break;
        }
        case STATE_LEVEL3:
        {
            break;
        }
        case STATE_LEVEL4:
        {
            break;
        }
        case STATE_SHOP:
        {
            break;
        }
        case STATE_EXIT:
        {
            break;
        }
        case STATE_GAME_OVER:
        {
            if(IsKeyPressed(KEY_ENTER))
            {
                *game = STATE_MENU;
                game_reset_level1();
            }
        }break;
    }
}
void game_draw(enum game_state* game)
{
    switch (*game)
    {
        case STATE_MENU :
        {
            ClearBackground(BLACK);
            menu_show(background);
        }break;
        case STATE_LEVEL_SELECT:
        {
            ClearBackground(BLACK);
            level_show(level_back);
        }break;
        case STATE_LEVEL1:
        {
            ClearBackground(BLACK);
            if (!level_map_ready)
            {
                grid_init(&map);
                grid_make_checker_grass(&map);
                level_map_ready = true;
                plant_grid_clear(plants);
            }
            grid_draw(&map, grass, soil, asphalt);
            draw_shop_bar(shop_bar, shop_rect);
            draw_plant_shop(plants_use_shop, plants_shop);
            char sunText[64];
            sprintf(sunText, "Sun: %d", sun_points);
            DrawText(sunText,200,40,30, BLACK);
            draw_suns(suns, sun);
            mouse_on_shop(GetMouseX(),GetMouseY());
            plant_grid_draw(plants);
            zombies_draw(zombies, MAX_ZOMBIES, zombie_tex);
            draw_bullets(bullets);
            mowers_draw(mowers, mower_tex);

            if(hover_row != -1 && hover_col != -1)
            {
                int x = ORIGIN_X + TILE_SIZE * hover_col;
                int y = ORIGIN_Y + TILE_SIZE * hover_row;
                bool can_plant = grid_can_place_plant(&map, hover_col, hover_row);
                bool is_occ = !plant_cell_is_empty(plants, hover_col, hover_row);
                Color border;
                if(!can_plant) border = RED;
                else if(is_occ) border = ORANGE;
                else border = GREEN;
                DrawRectangleLinesEx((Rectangle){ (float)x, (float)y, (float)TILE_SIZE, (float)TILE_SIZE }, 4, border);
            }
            if(hover_row != -1 && hover_col != -1 && selected_plant != PLANT_NONE)
            {
                bool can_plant = grid_can_place_plant(&map, hover_col, hover_row);
                bool is_occ = !plant_cell_is_empty(plants, hover_col, hover_row);

                Color preview = (can_plant && !is_occ) ? Fade(WHITE, 0.45f) : Fade(RED,  .45f);
                plant_draw_preview(plants,selected_plant, hover_col, hover_row, preview);
            }


        }break;
        case STATE_LEVEL2:
        {
            if (!level_map_ready)
            {
                grid_init(&map);
                grid_make_checker_grass(&map);
                level_map_ready = true;
            }
            grid_draw(&map, grass, soil, asphalt);
        }break;
        case STATE_LEVEL3:
        {
            if (!level_map_ready)
            {
                grid_init(&map);
                grid_make_checker_grass(&map);
                level_map_ready = true;
            }
            grid_draw(&map, grass, soil, asphalt);

        }break;
        case STATE_LEVEL4:
        {
            if (!level_map_ready)
            {
                grid_init(&map);
                grid_make_checker_grass(&map);
                level_map_ready = true;
            }
            grid_draw(&map, grass, soil, asphalt);
            break;
        }
        case STATE_SHOP:
        {
            ClearBackground(BLACK);
            shop_show(shop_back);
            draw_all_cards(all_plants, is_bought, forbidden);
            break;
        }
        case STATE_EXIT:
        {
            break;
        }
        case STATE_GAME_OVER:
        {
            ClearBackground(BLACK);
            DrawText("GAME-OVER",100,200,40, WHITE);
        }
    }
}

#include "zombie.h"

static float zombie_start_x(void)
{
    return ORIGIN_X + GRID_COLS * TILE_SIZE + 50.0f;
}

void zombies_init(Zombie* zombies, int count)
{
    for (int i = 0; i < count; i++)
        zombies[i].active = false;
}

void zombie_spawn_random_row(Zombie* zombies, int count)
{
    for (int i = 0; i < count; i++)
    {
        if (!zombies[i].active)
        {
            zombies[i].x = zombie_start_x();
            zombies[i].active = true;

            zombies[i].speed = 20.0f;
            zombies[i].health = 100;
            zombies[i].row = rand() % GRID_ROWS;

            zombies[i].attackInterval = 0.8f;
            zombies[i].attackTimer = zombies[i].attackInterval;
            zombies[i].damage = 20;
            break;
        }
    }
}

void zombies_update(Zombie* zombies, int count, float dt,
                    Plant plants[GRID_ROWS][GRID_COLS], bool* game_over, float rowMul[GRID_ROWS])
{
    for (int i = 0; i < count; i++)
    {
        if (!zombies[i].active) continue;

        if (zombies[i].health <= 0)
        {
            zombies[i].active = false;
            continue;
        }

        if (zombies[i].x > ORIGIN_X + GRID_COLS * TILE_SIZE)
        {
            zombies[i].x -= zombies[i].speed * dt * rowMul[zombies[i].row];
            continue;
        }

        // اگر از چپ رد شد => Game Over
        if (zombies[i].x < ORIGIN_X - 10.0f)
        {
            zombies[i].active = false;
            *game_over = true;
            continue;
        }

        int col = (int)((zombies[i].x - ORIGIN_X) / TILE_SIZE);
        int row = zombies[i].row;

        if (col >= GRID_COLS) col = GRID_COLS - 1;

        if (!plant_cell_is_empty(plants, col, row))
        {
            zombies[i].attackTimer -= dt;
            if (zombies[i].attackTimer <= 0.0f)
            {
                plants[row][col].health -= zombies[i].damage;
                zombies[i].attackTimer = zombies[i].attackInterval;

                if (plants[row][col].health <= 0)
                    plant_init_cel(&plants[row][col], PLANT_NONE);
            }
        }
        else
        {
            zombies[i].x -= zombies[i].speed * dt * rowMul[zombies[i].row];
            zombies[i].attackTimer = zombies[i].attackInterval;
        }
    }
}

void zombies_draw(const Zombie* zombies, int count, Texture2D tex)
{
    for (int i = 0; i < count; i++)
    {
        if (!zombies[i].active) continue;

        float x = zombies[i].x;
        float y = zombies[i].row * TILE_SIZE + ORIGIN_Y;

        Rectangle src = {0, 0, (float)tex.width, (float)tex.height};
        Rectangle dst = {x + TILE_SIZE / 2.0f, y + TILE_SIZE / 2.0f,
                         (float)TILE_SIZE, (float)TILE_SIZE};
        Vector2 origin = {TILE_SIZE / 2.0f, TILE_SIZE / 2.0f};

        DrawTexturePro(tex, src, dst, origin, 0.0f, WHITE);
    }
}

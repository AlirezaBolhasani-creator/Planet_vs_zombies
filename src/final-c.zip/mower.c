#include "mower.h"
#include "zombie.h"   // اینجا نیاز داریم چون به Zombie fields دسترسی داریم
#include <math.h>

static bool existsZombieAtLeft(int row, Zombie* zombies, int zombieCount)
{
    float triggerX = ORIGIN_X + TILE_SIZE * 0.2f; // نزدیک ستون 0

    for (int i = 0; i < zombieCount; i++)
    {
        if (!zombies[i].active) continue;
        if (zombies[i].row != row) continue;

        if (zombies[i].x <= triggerX) return true;
    }
    return false;
}

static void killZombiesInRowTouchingX(int row, float mowerX, Zombie* zombies, int zombieCount)
{
    float hitRange = TILE_SIZE * 0.45f;

    for (int z = 0; z < zombieCount; z++)
    {
        if (!zombies[z].active) continue;
        if (zombies[z].row != row) continue;

        if (fabsf(mowerX - zombies[z].x) < hitRange)
        {
            zombies[z].health = 0;
            zombies[z].active = false;
        }
    }
}

void mowers_init(Mower mowers[GRID_ROWS])
{
    for (int r = 0; r < GRID_ROWS; r++)
    {
        mowers[r].row = r;

        mowers[r].x = ORIGIN_X + TILE_SIZE * 0.5f;
        mowers[r].y = ORIGIN_Y + r * TILE_SIZE + TILE_SIZE * 0.5f;

        mowers[r].active = false;
        mowers[r].available = true;
        mowers[r].speed = 200.0f;
    }
}

void mowers_update(Mower mowers[GRID_ROWS], Zombie* zombies, int zombieCount, float dt)
{
    for (int r = 0; r < GRID_ROWS; r++)
    {
        if (!mowers[r].available && !mowers[r].active) continue;

        if (!mowers[r].active)
        {
            if (existsZombieAtLeft(r, zombies, zombieCount))
                mowers[r].active = true;
        }
        else
        {
            mowers[r].x += mowers[r].speed * dt;

            // هر فریم زامبی‌های سر راه را بکش
            killZombiesInRowTouchingX(r, mowers[r].x, zombies, zombieCount);

            if (mowers[r].x > ORIGIN_X + GRID_COLS * TILE_SIZE + TILE_SIZE)
            {
                mowers[r].active = false;
                mowers[r].available = false;
            }
        }
    }
}

void mowers_draw(const Mower mowers[GRID_ROWS], Texture2D tex)
{
    for (int r = 0; r < GRID_ROWS; r++)
    {

        // اگر استفاده شده و حرکت هم نمی‌کند، نکش
        if (!mowers[r].available) continue;

        Rectangle src = {0, 0, (float)tex.width, (float)tex.height};
        Rectangle dst = {mowers[r].x, mowers[r].y, (float)TILE_SIZE, (float)TILE_SIZE};
        Vector2 origin = {TILE_SIZE / 2.0f, TILE_SIZE / 2.0f};
        DrawTexturePro(tex, src, dst, origin, 0.0f, WHITE);
    }
}
int mower_available_in_row(const Mower mowers[], int row)
{
    if(mowers[row].available)
        return 1;
    return 0;
}
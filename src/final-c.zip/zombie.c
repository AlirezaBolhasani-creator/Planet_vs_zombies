#include "zombie.h"
#include "animation.h"
static int last_col[MAX_ZOMBIES];

static Animation zombieWalkAnim;
static Animation zombieHitAnim;
static Animation zombieDieAnim;
static Animation zombieFlagWalkAnim;
static Animation zombieFlagHitAnim;
static ZombieAnimState pick_walk_state(const Zombie* z)
{
    return (z->type == ZOMBIE_THINKING) ? ZOMBIE_FLAG_WALK : ZOMBIE_WALK;
}

static ZombieAnimState pick_hit_state(const Zombie* z)
{
    return (z->type == ZOMBIE_THINKING) ? ZOMBIE_FLAG_HIT : ZOMBIE_HIT;
}

void zombies_load_animations()
{
    zombieWalkAnim = Animation_Load(ASSET("zombie_walk.png"),41, 56, 7, 12, true, 1);
    zombieHitAnim = Animation_Load(ASSET("zombie_eat.png"),41, 56, 7, 10, true, 1);
    zombieDieAnim = Animation_Load(ASSET("zombie_fall.png"),41, 56, 5, 8, false, 1);
    zombieFlagHitAnim = Animation_Load(ASSET("zombie_flag_eat.png"),41, 56, 7, 12, true, 1);
    zombieFlagWalkAnim = Animation_Load(ASSET("zombie_flag_walk.png"),41, 56, 7, 10, true, 1);

}
static float plant_ratio(const Plant* p)
{
    if(p->alive == false || p->maxHealth <= 0.0f)return 0.0f;
    return (float)p->health / (float)p->maxHealth;
}
static float row_weight(int row, const Plant plants[GRID_ROWS][GRID_COLS],const Mower mowers[GRID_COLS])
{
    int n = 0;
    float s = 0.0f, q = 0.0f;
    for(int c = 0; c < GRID_COLS; c++)
    {
        const Plant* p = &plants[row][c];
        if(p->alive == true && p->type != PLANT_NONE)
        {
            float r = plant_ratio(p);
            s += r;
            q += r * r;
            n++;
        }
    }
    // det = 1 - Q^2 - n^2 - S^2 + 2*n*Q*S
    float det = 1.0f - (q*q) - (float)(n*n) - (s*s) + 2.0f*(float)n*q*s;
    float mower_term = 0.0f;
    if(mowers[row].active == true)
        mower_term = 1.0f;
    return 10 * mower_term + det;
}
static int thinking_choose_row(int currentRow,const Plant plants[GRID_ROWS][GRID_COLS],const Mower mowers[GRID_ROWS])
{
    int candidates[3] = {currentRow-1, currentRow, currentRow+1};
    int bestRow = currentRow;
    float bestW = row_weight(currentRow, plants, mowers);

    for(int i = 0; i < 3; i++)
    {
        if(candidates[i] < 0 || candidates[i] >= GRID_ROWS)continue;
        float w = row_weight(candidates[i], plants, mowers);
        if(w < bestW)
        {
            bestRow = candidates[i];
            bestW = w;
        }
    }
    return bestRow;
}
static float zombie_start_x(void)
{
    return ORIGIN_X + GRID_COLS * TILE_SIZE + 50.0f;
}
void zombies_init(Zombie* zombies, int count)
{
    for (int i = 0; i < count; i++)
    {
        zombies[i].active = false;
        last_col[i] = -1;
        zombies[i].type = ZOMBIE_NORMAL;
        zombies[i].animState = ZOMBIE_WALK;
        zombies[i].anim = zombieWalkAnim;
        Animation_Reset(&zombies[i].anim);

    }
}
void zombie_set_state(Zombie* z, ZombieAnimState newState)
{
    if (z->animState == newState) return;

    z->animState = newState;

    switch (newState)
    {
        case ZOMBIE_WALK: z->anim = zombieWalkAnim; break;
        case ZOMBIE_HIT:  z->anim = zombieHitAnim;  break;
        case ZOMBIE_DIE:  z->anim = zombieDieAnim;  break;
        case ZOMBIE_FLAG_HIT : z->anim = zombieFlagHitAnim; break;
        case ZOMBIE_FLAG_WALK : z->anim = zombieFlagWalkAnim; break;
    }

    Animation_Reset(&z->anim);
}

static int x_to_col(float x)
{
    int col = (int)floorf((x - ORIGIN_X) / (float)TILE_SIZE);
    if(col <= 0) return 0;
    if(col >= GRID_COLS) return GRID_COLS - 1;
    return col;
}

void zombie_spawn_random_row(Zombie* zombies, int count)
{
    for (int i = 0; i < count; i++)
    {
        if (!zombies[i].active)
        {
            zombies[i].x = zombie_start_x();
            zombies[i].active = true;

            zombies[i].speed = 200.0f;
            zombies[i].health = 100;
            zombies[i].row = rand() % GRID_ROWS;

            zombies[i].attackInterval = 0.8f;
            zombies[i].attackTimer = zombies[i].attackInterval;
            zombies[i].damage = 20;

            zombies[i].anim = zombieWalkAnim;
            Animation_Reset(&zombies[i].anim);
            Zombie* z = &zombies[i];
            z->type = ZOMBIE_NORMAL;
            zombie_set_state(z, ZOMBIE_WALK);

            break;
        }
    }
}

void zombies_update(Zombie* zombies, int count, float dt,Plant plants[GRID_ROWS][GRID_COLS],
                    bool* game_over, float rowMul[GRID_ROWS], const Mower mowers[GRID_ROWS])
{
    for (int i = 0; i < count; i++)
    {
        Zombie* z = &zombies[i];
        if (!z->active) continue;

        int col = x_to_col(z->x);
        int row = z->row;
        bool hasPlantAhead = !plant_cell_is_empty(plants, col, row);

        if (z->health <= 0)
        {
            zombie_set_state(z, ZOMBIE_DIE);  // (فعلاً die مشترک)
            Animation_Update(&z->anim, dt);
            if(z->anim.finished)
            {
                z->active = false;
            }
        }
        else if (hasPlantAhead) zombie_set_state(z, pick_hit_state(z));
        else zombie_set_state(z, pick_walk_state(z));


        Animation_Update(&z->anim, dt);
        if (zombies[i].x > ORIGIN_X + GRID_COLS * TILE_SIZE)
        {
            zombies[i].x -= zombies[i].speed * dt * rowMul[zombies[i].row];
            continue;
        }

        // اگر از چپ رد شد => Game Over
        if (zombies[i].x < ORIGIN_X - 10.0f)
        {
            zombies[i].active = false;
            *game_over = true;
            continue;
        }
        if (!plant_cell_is_empty(plants, col, row))
        {
            zombies[i].attackTimer -= dt;
            if (zombies[i].attackTimer <= 0.0f)
            {
                plants[row][col].health -= zombies[i].damage;
                zombies[i].attackTimer = zombies[i].attackInterval;

                if (plants[row][col].health <= 0)
                    plant_init_cel(&plants[row][col], PLANT_NONE);
            }
        }
        else
        {
            int col_now = x_to_col(zombies[i].x);
            if (zombies[i].type == ZOMBIE_THINKING)
            {
                if (last_col[i] != col_now)
                {
                    int newRow = thinking_choose_row(zombies[i].row, plants, mowers);
                    zombies[i].row = newRow;
                    last_col[i] = col_now;
                }
            }
            else
            {
                last_col[i] = col_now;
            }

            zombies[i].x -= zombies[i].speed * dt * rowMul[zombies[i].row];
            zombies[i].attackTimer = zombies[i].attackInterval;
        }
    }
}
void zombies_draw(const Zombie* zombies, int count)
{
    for (int i = 0; i < count; i++)
    {
        const Zombie* z = &zombies[i];
        if(!z->active) continue;

        Vector2 pos = { z->x, ORIGIN_Y + z->row * TILE_SIZE };
        Animation_Draw((Animation*)&z->anim, pos, 1.5f);
    }
}

void zombie_spawn_thinking_random_row(Zombie zombies[], int max)
{
    int index = -1;
    for(int i = 0; i < MAX_ZOMBIES; i++)
    {
        if(zombies[i].active == false)
        {
            index = i;
            break;
        }
    }
    if(index < 0)
        return;

    int row = rand() % GRID_ROWS;

    zombies[index].x = zombie_start_x();
    zombies[index].active = true;

    zombies[index].speed = 20.0f;
    zombies[index].health = 100;
    zombies[index].row = row;

    zombies[index].attackInterval = 0.8f;
    zombies[index].attackTimer = zombies[index].attackInterval;
    zombies[index].damage = 20;
    zombies[index].anim = zombieWalkAnim;
    zombies[index].animState = ZOMBIE_WALK;
    Animation_Reset(&zombies[index].anim);

    zombies[index].type = ZOMBIE_THINKING;
    zombie_set_state(&zombies[index], ZOMBIE_FLAG_WALK);
}


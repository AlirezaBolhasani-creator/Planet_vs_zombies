#include "animation.h"
#include <stdio.h>
Animation Animation_Load(
        const char* file,
        int frameWidth,
        int frameHeight,
        int frameCount,
        float fps,
        bool loop,
        int padding
){
    Animation a = (Animation){0};

    // Load image first (so we can replace background color)
    Image img = LoadImage(file);

    // If image failed, return empty animation
    if (img.data == NULL || img.width <= 0 || img.height <= 0) {
        // texture.id will be 0 -> caller can detect failure
        return a;
    }

    // Replace purple background with transparent (adjust if your purple differs)
    ImageColorReplace(&img, (Color){128, 0, 128, 255}, (Color){0, 0, 0, 0});

    a.texture = LoadTextureFromImage(img);
    UnloadImage(img);

    a.frameWidth  = frameWidth;
    a.frameHeight = frameHeight;
    a.frameCount  = frameCount;
    a.fps         = fps;
    a.loop        = loop;
    a.padding     = padding;

    a.currentFrame = 0;
    a.timer        = 0.0f;
    a.finished     = false;

    return a;
}

void Animation_Reset(Animation* anim)
{
    anim->currentFrame = 0;
    anim->timer = 0.0f;
    anim->finished = false;
}

void Animation_Update(Animation* anim, float dt)
{
    if (!anim) return;
    if (anim->finished) return;
    if (anim->fps <= 0.0f) return;
    if (anim->frameCount <= 0) return;

    anim->timer += dt;
    float frameTime = 1.0f / anim->fps;

    while (anim->timer >= frameTime)
    {
        anim->timer -= frameTime;
        anim->currentFrame++;

        if (anim->currentFrame >= anim->frameCount)
        {
            if (anim->loop) anim->currentFrame = 0;
            else {
                anim->currentFrame = anim->frameCount - 1;
                anim->finished = true;
            }
        }
    }
}

void Animation_Draw(const Animation* anim, Vector2 pos, float scale)
{
    if (!anim) return;
    if (anim->texture.id == 0) return;

    // src.x باید padding رو حساب کنه
    float srcX = (float)(anim->currentFrame * (anim->frameWidth + anim->padding));

    Rectangle src = {
            srcX,
            0.0f,
            (float)anim->frameWidth,
            (float)anim->frameHeight
    };

    Rectangle dst = {
            pos.x,
            pos.y,
            (float)anim->frameWidth * scale,
            (float)anim->frameHeight * scale
    };

    DrawTexturePro(anim->texture, src, dst, (Vector2){0,0}, 0.0f, WHITE);
}

void Animation_Unload(Animation* anim)
{
    if (!anim) return;
    if (anim->texture.id != 0) UnloadTexture(anim->texture);
    anim->texture = (Texture2D){0};
}

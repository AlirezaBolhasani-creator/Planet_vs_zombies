#include "bullet.h"
#include "raylib.h"
void bullet_init(Bullet *bullets)
{
    for(int i = 0; i < MAX_BULLETS; i++)
    {
        bullets[i].active = false;
    }
}
void spawn_bullet(int row, int col,Bullet *bullets)
{
    for(int i = 0; i < MAX_BULLETS; i++)
    {
        if(!bullets[i].active)
        {
            bullets[i].row = row;
            bullets[i].active = true;
            bullets[i].x = ORIGIN_X + col * TILE_SIZE + TILE_SIZE * 0.8;
            bullets[i].speed = 220.0f;
            bullets[i].damage = 20;
            break;
        }
    }
}
void bullet_update(Bullet *bullets, float dt)
{
    for(int i = 0; i < MAX_BULLETS; i++)
    {
        if(!bullets[i].active) continue;

        bullets[i].x += bullets[i].speed * dt;
        if(bullets[i].x > ORIGIN_X + TILE_SIZE * GRID_COLS)
        {
            bullets[i].active = false;
        }
    }
}
void draw_bullets(Bullet *bullets)
{
    for(int i = 0; i < MAX_BULLETS; i++)
    {
        if(bullets[i].active)
        {
            DrawCircle((int)bullets[i].x, ORIGIN_Y + bullets[i].row*TILE_SIZE + TILE_SIZE/2, 6, GREEN);
        }
    }
}

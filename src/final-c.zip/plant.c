#include "plant.h"
#include "grid.h"
#include "raylib.h"
static PlantTextures g_tex;
static Animation sunflower_anim;
void plants_load_anim()
{
    sunflower_anim = Animation_Load(ASSET("sunflower_idle.png"), 31, 33, 6, 12, true, 0);
}
void plant_set_textures(PlantTextures tex)
{
    g_tex = tex;
}

static const float NORMAL_COVER  = 1.0f;
static const float PREVIEW_SCALE = 0.85f;

static void draw_plant_tex_tinted(Texture2D tex, int x, int y, float cover, Color tint)
{
    float maxDim = (float)(TILE_SIZE) * cover;
    float s1 = maxDim / (float)tex.width;
    float s2 = maxDim / (float)tex.height;
    float scale = (s1 < s2) ? s1 : s2;

    float w = (float)tex.width * scale;
    float h = (float)tex.height * scale;

    Rectangle src = {0, 0, (float)tex.width, (float)tex.height };
    Rectangle dst = {(float)x + TILE_SIZE/2.0f, (float )y + TILE_SIZE/2.0f, w, h };
    Vector2 origin = { w/2.0f, h/2.0f };

    DrawTexturePro(tex, src, dst, origin, 0.0f, tint);
}

static void draw_plant_tex(Texture2D tex, int x, int y, float cover)
{
    draw_plant_tex_tinted(tex, x, y, cover, WHITE);
}

void plant_grid_clear(Plant plants[GRID_ROWS][GRID_COLS])
{
    for (int r = 0; r < GRID_ROWS; r++)
    {
        for (int c = 0; c < GRID_COLS; c++)
        {
            plants[r][c].type = PLANT_NONE;
            plants[r][c].alive = false;
            plants[r][c].row = r;
            plants[r][c].col = c;
        }
    }
}

void plant_grid_draw(const Plant plants[GRID_ROWS][GRID_COLS])
{
    for (int r = 0; r < GRID_ROWS; r++)
    {
        for (int c = 0; c < GRID_COLS; c++)
        {
            plant_type t = plants[r][c].type;
            if (t == PLANT_NONE) continue;

            int x = ORIGIN_X + c * TILE_SIZE;
            int y = ORIGIN_Y + r * TILE_SIZE;

            switch (t)
            {
                case PLANT_PEA:
                    draw_plant_tex(g_tex.pea, x, y, NORMAL_COVER);
                    break;

                case PLANT_SUNFLOWER:
                    draw_plant_tex(g_tex.sunflower, x, y, NORMAL_COVER);
                    break;

                case PLANT_WALLNUT:
                    draw_plant_tex(g_tex.wallnut, x, y, NORMAL_COVER);
                    break;
                case PLANT_CHOMPER:
                    draw_plant_tex(g_tex.chomper_tex, x, y, NORMAL_COVER);
                    break;
                default:
                    break;
            }
        }
    }
}
bool plant_cell_is_empty(const Plant plants[GRID_ROWS][GRID_COLS], int col, int row)
{
    if (!grid_in_bounds(col, row)) return false;
    return plants[row][col].type == PLANT_NONE;
}
bool plant_place(Plant plants[GRID_ROWS][GRID_COLS], plant_type t, int col, int row)
{
    if (!grid_in_bounds(col, row)) return false;
    if (plants[row][col].type != PLANT_NONE) return false;
    plants[row][col].row = row;
    plants[row][col].col = col;
    plant_init_cel(&plants[row][col],t);
    return true;
}
bool plant_remove(Plant plants[GRID_ROWS][GRID_COLS], int col, int row)
{
    if (!grid_in_bounds(col, row)) return false;
    if (plants[row][col].type == PLANT_NONE) return false;

    plants[row][col].type = PLANT_NONE;
    plants[row][col].alive = false;
    return true;
}
void plant_draw_preview(Plant plants[GRID_ROWS][GRID_COLS] ,plant_type t, int col, int row, Color tint)
{
    if (!grid_in_bounds(col, row)) return;
    if(plants[row][col].type != PLANT_NONE) return;
    int x = ORIGIN_X + col * TILE_SIZE;
    int y = ORIGIN_Y + row * TILE_SIZE;

    float previewCover = NORMAL_COVER * PREVIEW_SCALE;

    switch (t)
    {
        case PLANT_PEA:
            draw_plant_tex_tinted(g_tex.pea, x, y, previewCover, tint);
            break;

        case PLANT_SUNFLOWER:
            draw_plant_tex_tinted(g_tex.sunflower, x, y, previewCover, tint);
            break;

        case PLANT_WALLNUT:
            draw_plant_tex_tinted(g_tex.wallnut, x, y, previewCover, tint);
            break;
        case PLANT_CHOMPER:
            draw_plant_tex_tinted(g_tex.chomper_tex, x, y, previewCover, tint);
            break;
        default:
            break;
    }
}
void plant_init_cel(Plant *p, plant_type t)
{
    p->type = t;
    p->alive = (t != PLANT_NONE);
    if(t == PLANT_PEA)
    {
        p->maxHealth = p->health = 100;
        p->cooldown = 5.0f;
        p->cooldownTimer = p->cooldown;
        p->actionInterval = 1.0f;
        p->actionTimer = p->actionInterval;
    }
    else if(t == PLANT_SUNFLOWER)
    {
        p->maxHealth = p->health = 80;
        p->cooldownTimer = p->cooldown = 5.0f;
        p->actionInterval = 7.0f;
        p->actionTimer = p->actionInterval;
    }
    else if(t == PLANT_WALLNUT)
    {
        p->maxHealth = p->health = 300;
        p->cooldownTimer = p->cooldown = 5.0f;
        p->actionInterval = p->actionTimer = 0.0f;
    }
    else if(t == PLANT_CHOMPER)
    {
        p->maxHealth = p->health = 150;
        p->cooldownTimer= p->cooldown = 10.0f;
        p->actionInterval = 0.0f;
        p->actionTimer = 0.0f;
        p->lifeTime = 20.0f;
        p->lifeTimer = p->lifeTime;
    }
    else
    {
        p->maxHealth = p->health = 0;
        p->cooldownTimer = p->cooldown = 0.0f;
        p->actionInterval = p->actionTimer = 0.0f;
    }
}
int plant_collect_events(Plant plants[GRID_ROWS][GRID_COLS], float dt,
                         PlantEvent* out_events, int max_events)
{
    int count = 0;

    for (int row = 0; row < GRID_ROWS; row++)
    {
        for (int col = 0; col < GRID_COLS; col++)
        {
            Plant *p = &plants[row][col];

            if (p->type == PLANT_NONE || !p->alive) continue;
            if (p->health <= 0)
            {
                plant_init_cel(p, PLANT_NONE);
                continue;
            }
            if (p->actionInterval > 0.0f)
            {
                p->actionTimer -= dt;
                if (p->actionTimer <= 0.0f)
                {
                    if (count < max_events)
                    {
                        if (p->type == PLANT_PEA)
                            out_events[count++] = (PlantEvent){ EVENT_SPAWN_BULLET, row, col };
                        else if (p->type == PLANT_SUNFLOWER)
                            out_events[count++] = (PlantEvent){ EVENT_SPAWN_SUN, row, col };
                    }
                    p->actionTimer = p->actionInterval;
                }
            }
            if (p->type == PLANT_CHOMPER)
            {
                p->lifeTimer -= dt;
                if (p->lifeTimer <= 0.0f)
                    plant_init_cel(p, PLANT_NONE);
            }
        }
    }
    return count;
}
int count_plants_in_row(const Plant plants[GRID_ROWS][GRID_COLS], int row)
{
    int count = 0;
    for (int c = 0; c < GRID_COLS; c++)
    {
        if(plants[row][c].alive == false || plants[row][c].type == PLANT_NONE)continue;
        count++;
    }
    return count;
}
#ifndef ZOMBIE_H
#define ZOMBIE_H

#include <stdbool.h>
#include <stdlib.h>
#include "raylib.h"
#include "config.h"
#include "plant.h"
#include "sun.h"
#include "mower.h"
#include "bullet.h"
typedef enum
{
    ZOMBIE_NORMAL,
    ZOMBIE_THINKING
}ZombieType;
typedef struct Zombie
{
    bool  active;
    int   health;
    int   row;
    float x;
    float speed;

    float attackInterval;
    float attackTimer;
    int   damage;
    ZombieType type;
    float stepProgress;

} Zombie;
void zombies_init(Zombie* zombies, int count);
void zombie_spawn_random_row(Zombie* zombies, int count);
void zombies_update(Zombie* zombies, int count, float dt,Plant plants[GRID_ROWS][GRID_COLS], bool* game_over, float rowMul[GRID_ROWS]);
void zombies_draw(const Zombie* zombies, int count, Texture2D tex);

#endif
